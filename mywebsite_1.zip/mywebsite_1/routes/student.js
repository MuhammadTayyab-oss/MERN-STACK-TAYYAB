var express = require('express');
var router = express.Router();
const student_controller =require('../controller/student_controller')

/* GET home page. */

router.get('/list',student_controller.product_list) 
  

module.exports=router;