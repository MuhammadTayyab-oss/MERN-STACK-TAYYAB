const mongoose =require('mongoose');
const Schema=mongoose.Schema;
let StudentSchema=new mongoose.Schema({
    reg_id:{type:Number, required:true},
    name:{type:String, required: true, max:100 },
    gender:{type:String, required: true, max: 7},
    city:{type:String, required: true, max:100 },
    age:{type:Number, required: true }
});

module.exports=mongoose.model('Student',StudentSchema);