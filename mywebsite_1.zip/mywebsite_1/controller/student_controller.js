
const Student=require('../models/student.model');

exports.product_list=(req,res)=>{
Student.find((err,student)=>{

    if(!err){
        res.render('list',{
            page : 'Student List',
            menuId: 'list',
            student: student
        });
        
    }
    else{
        console.log("Error occured in retrieving students:"+JSON.stringify(err, undefined, 2));
    
    }

});


}


